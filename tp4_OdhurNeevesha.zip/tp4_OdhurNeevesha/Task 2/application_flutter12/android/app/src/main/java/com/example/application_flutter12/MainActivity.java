package com.example.application_flutter12;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
