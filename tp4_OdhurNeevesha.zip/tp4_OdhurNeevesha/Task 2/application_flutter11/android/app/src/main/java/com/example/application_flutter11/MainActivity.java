package com.example.application_flutter11;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
