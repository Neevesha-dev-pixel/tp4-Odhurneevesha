package com.example.application_fluttertp4;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
